

import java.io.IOException;

import java.io.PrintWriter;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mvc1.data;
import com.mvc1.service;
 
public class login_servlet extends HttpServlet {
	 
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String u_email=request.getParameter( "email");
		String u_password=request.getParameter( "password");
		
		 HttpSession hs=  request.getSession();
		hs.setAttribute("email", u_email);
		hs.setAttribute("password",u_password);
		
		PrintWriter out=response.getWriter();
					
		
		
		service ss=new service();
		Vector v=ss.login_logic();
		
		
		
		 if(v.contains(u_email)&&v.contains(u_password))
		  {
	
			 out.println("<h1>LOGIN SUCCESS<h1>");
			 
			 RequestDispatcher rd=request.getRequestDispatcher("fetch_servlet");
			 rd.forward(request, response);
			 
		  }
		 else
		 {
			 
		
			 out.println("<h1>LOGIN FAIL<h1>");
			 RequestDispatcher rd=request.getRequestDispatcher("login.html");
			 rd.include(request,response);
			 
		 }
		
		 
		
		
		
	}
} 