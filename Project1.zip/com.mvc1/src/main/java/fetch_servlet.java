

import java.io.IOException;

import java.io.PrintWriter;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mvc1.data;
import com.mvc1.service;
public class fetch_servlet extends HttpServlet 
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		PrintWriter out=response.getWriter();
		
		
		
		HttpSession hs=request.getSession(false);
		
		if(hs!=null)
		{	
			
			
		String email=(String)hs.getAttribute("email");
		String password=(String)hs.getAttribute("password");
		
		data dd=new data();
		dd.setEmail(email);
		dd.setPassword(password);
		
		service ss=new service();
		Vector<data> v=ss.fetch_logic(dd);
		
		
		out.println("email:"+email);
		out.println("<br");
		out.println("password:"+password);
		
		for(data d:v)
		{
			out.println("<br><br>");
			out.println("<table border='1'>");
			
			out.println("<tr>");
			out.println("<td>"+d.getName()+"</td>");
			out.println("<td>"+d.getEmail()+"</td>");
			out.println("<td>"+d.getPassword()+"</td>");
		    out.println("<td>"+d.getContact()+"</td>");
		    out.println("<td>"+d.getGender()+"</td>");
		    out.println("<td>"+d.getDateofbirth()+"</td>");
		    out.println("<td>"+d.getAddress()+"</td>");
		    out.println("<td>"+d.getLanguage()+"</td>");
		   // out.println("<td>"+dd.getFile()+"</td>");
		  //  out.println("<td>"+dd.getImage()+"</td>");
		    out.println("</tr>");
		    out.println("<table><br>");
		  
		   
		}
		 RequestDispatcher rd=request.getRequestDispatcher("logout_ser");
		    rd.include(request, response);
		}
		else 
		{
			out.println("<h1>Your HAcker pls Login with valid Credintials</h1>");
			out.println("<a href='login.html'>Click for login");
			
		}
		
		    
		    
		}    
		    
	}	    
		    
 

	    
		
		
	
		    
		    
		    
		    
		    
		    
		    
		    

		
		
		
	

	

