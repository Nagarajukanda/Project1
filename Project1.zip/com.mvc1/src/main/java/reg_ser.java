

import java.io.IOException;

import java.io.PrintWriter;

import javax.naming.Name;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.crypto.Data;

import com.mvc1.data;
import com.mvc1.service;

public class reg_ser extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
	 String name=request.getParameter("name");
	 String email=request.getParameter( "email");
	 String password=request.getParameter( "password");
	 String contact=request.getParameter( "contact");
	 String gender=request.getParameter("gender"); 
	 String dateofbirth=request.getParameter("dateofbirth"); 
	 String address=request.getParameter( "address");
	 String language=request.getParameter( "language");
	 String fileupload=request.getParameter( "file");
	 String imgupload=request.getParameter("image");
	
		PrintWriter out=response.getWriter();
			 
		out.println(name);
		out.println(email);
		out.println(password);
		out.println(contact);
		out.println(gender);
		out.println(dateofbirth);
		out.println(address);
		out.println(language);
		out.println(fileupload);
		out.println(imgupload);
	
		
			 data dd=new data();
			  
				 dd.setName(name);
				 dd.setEmail(email);
				 dd.setPassword(password);
				 dd.setContact(contact);
				 dd.setGender(gender);
				 dd.setDateofbirth(dateofbirth);
				 dd.setAddress(address);
				 dd.setLanguage(language);
				 dd.setFile(fileupload);
				 dd.setImage(imgupload);
				
				
				service ss=new service ();
				 int i=ss.reg_logic(dd);
				 
				 out.println("updated:"+i);
				
			 } 

	 
	}

			 
			 
			 
			 
			 
			 
			 
			 
	
	


