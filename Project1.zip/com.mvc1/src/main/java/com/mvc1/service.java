package com.mvc1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.Reader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Properties;
import java.util.Vector;

import javax.sql.rowset.JdbcRowSet;
import javax.sql.rowset.RowSetFactory;
import javax.sql.rowset.RowSetProvider;
import javax.swing.text.DefaultStyledDocument;

public class service  
{
	public static Connection mycon()
	{
		Connection con=null;
		try
		{
		FileInputStream ff=new FileInputStream("C:\\Users\\NAGARAJU\\eclipse-workspace\\com.mvc1\\src\\jdbc.properties");
				Properties p=new Properties();
				p.load( ff);
				
		Class.forName(p.getProperty("driver")).newInstance();
		con=DriverManager.getConnection( p.getProperty("url"),p.getProperty("username"),p.getProperty("password"));
		System.out.println(con);
	}
		
		catch(Exception ee)
		{
			ee.printStackTrace();
		}
	
		return con;
	
		
	}
	
	
	public int reg_logic(data dd)
	{
		int i=0;
		Connection con=service.mycon();
		
		try
		{
		PreparedStatement pst=con.prepareStatement("insert into mvc1 values(?,?,?,?,?,?,?,?,?,?)");
		
		pst.setString(1,dd.getName());
		pst.setString(2,dd.getEmail());
		pst.setString(3,dd.getPassword());
		pst.setString(4,dd.getContact());
		pst.setString(5,dd.getGender());
		pst.setString(6,dd.getDateofbirth());
		pst.setString(7,dd.getAddress());
		pst.setString(8,dd.getLanguage());
		
		FileReader fr=new FileReader(dd.getFile());
		pst.setCharacterStream(9,fr);
		
		FileInputStream fi=new FileInputStream(dd.getImage());
		pst.setBinaryStream(10,fi);
		
		i=pst.executeUpdate();
		 System.out.println(i);
		
	}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	return i;
}
	public Vector login_logic()
	{
		Vector v=new Vector();
		Connection con=service.mycon();
		try
		{
		FileInputStream ff=new FileInputStream("C:\\Users\\NAGARAJU\\eclipse-workspace\\com.mvc1\\src\\jdbc.properties");
		Properties p=new Properties();
		p.load( ff);
		
		
		Class.forName(p.getProperty("driver")).newInstance();
		RowSetFactory rf= RowSetProvider.newFactory();
		JdbcRowSet jr=rf.createJdbcRowSet();
		
		jr.setUrl(p.getProperty("url"));
		jr.setUsername(p.getProperty("username"));
		jr.setPassword(p.getProperty("password"));
		
		
		jr.setCommand("select email, password from mvc1");
	//	jr.setString(1,"email");
	//	jr.setString(2, "password");
		jr.execute();
		
		 
		  
		  for(;jr.next();)
		  {
			  v.add(jr.getString("email"));
			  v.add(jr.getString("password"));
			  
		  }
		
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return v;
		
	}

	public Vector fetch_logic(data dd)
	{
		Vector v=new Vector();
		
		
		
		Connection con=service.mycon();
		try
		{
		FileInputStream ff=new FileInputStream("C:\\Users\\NAGARAJU\\eclipse-workspace\\com.mvc1\\src\\jdbc.properties");
		Properties p=new Properties();
		p.load( ff);
		
		
		Class.forName(p.getProperty("driver")).newInstance();
		RowSetFactory rf= RowSetProvider.newFactory();
		JdbcRowSet jr=rf.createJdbcRowSet();
		
		jr.setUrl(p.getProperty("url"));
		jr.setUsername(p.getProperty("username"));
		jr.setPassword(p.getProperty("password"));
		
		jr.setCommand("select*from mvc1 where email=?");
		jr.setString(1,dd.getEmail());
	    
		
	
		jr.execute();
		
		 
		for(;jr.next();)
		{
		
			//data dd=new data();
			
			dd.setName(jr.getString("name"));
			dd.setEmail(jr.getString("email"));
			dd.setPassword(jr.getString("password"));
			dd.setContact(jr.getString("contact"));
			dd.setGender(jr.getString("gender"));
			dd.setDateofbirth(jr.getString("dateofbirth"));
			dd.setAddress(jr.getString("address"));
			dd.setLanguage(jr.getString("language"));
			v.add(dd);
		}
		}
		   /* 
			 Reader r=jr.getCharacterStream("file");
			 File f1=new File("file.txt");
			 
			
				for(int in; (in=r.read())!=-1; in++)
				{
					FileWriter fw=new FileWriter("dbtext.txt");
					 File fle=new File("in");
					System.out.print((char)in);
					dd.setFile(fle.getAbsolutePath());
				}
				
				
				InputStream ii=jr.getBinaryStream("image");
				File f2=new File("image.jpg");
			
				for(int in2; (in2=ii.read())!=-1; in2++)
				{
				System.out.println((char)in2);
				
				}
				System.out.println(f1.getAbsolutePath());
				
				
				
			
				
			}
		
		}*/
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return v;
	}
   public int update_logics(data d)
    
   {
	   int i=0;
	   Connection con=service.mycon();
	   try
	   {
	 PreparedStatement pst=con.prepareStatement("update mvc1 set contact=? where contact=?");
	 
	 			pst.setString( 1,d.getNewcont());
	 			pst.setString( 2,d.getOldcont());
	 			
	 		i=pst.executeUpdate();
	 		System.out.println(i);
	   
   }
	   catch (Exception e) {
		// TODO: handle exception
		   e.printStackTrace();
	}
	
	
	return i;
	
	
	
	
	
}			
			
			
}		
			
		
		
		
		
		
		
		
		
			
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
