package com.mvc1;

public class data {
	
	
	private String name;
	private String email;
	private String password;
	private String contact;
	private String gender;
	private String dateofbirth;
	private String address;
	private String language;
	private String file;
	private String image;
	private String newcont;
	private String oldcont;
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDateofbirth() {
		return dateofbirth;
	}
	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getNewcont() {
		return newcont;
	}
	public void setNewcont(String newcont) {
		this.newcont = newcont;
	}
	public String getOldcont() {
		return oldcont;
	}
	public void setOldcont(String oldcont) {
		this.oldcont = oldcont;
	}
	
	
	
	
}
	
	
	
	